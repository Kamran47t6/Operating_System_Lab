#include<iostream>
using namespace std;

int main()
{
    cout << "Testing G++ Compiler!!!!!!!" << endl;
    cout << "Yes, G++ Compiler working Perfectly!!!!!!!" << endl;
    return 0;
}

