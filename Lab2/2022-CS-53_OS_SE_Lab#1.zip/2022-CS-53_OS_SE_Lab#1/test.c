#include<stdio.h>
void main() {
 	printf("Hello! This is my first C program with Ubuntu 11.10\n"); 		/* Do something more if you want */ 
} 

