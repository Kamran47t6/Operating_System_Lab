### Task#1

To install Ubuntu we have to first install VMware that is Virtualization Software Package help us to run Guest Operating System on a Host Operating System. To install VMWare click [this link]([Typora — a markdown editor, markdown reader.](https://typora.io/)) and choose Try Workstation 17 Player for Windows

After VMware installation, now we have to install Ubuntu file. Follow [this link](https://ubuntu.com/download/desktop) and install according to your computer Architecture. Now open the VMware and choose first option as shown below

![VMware](C:\Users\Dulmi\Downloads\v1.PNG)

Continue and Finish

![v2](C:\Users\Dulmi\Downloads\v2.PNG)

Click on Create a New Virtual Machine, after that

![v3](C:\Users\Dulmi\Downloads\v3.PNG)

Choose Installer disc image file and browse the Ubuntu iso file where you download it. The file look like this

![v4](C:\Users\Dulmi\Downloads\v4.png)

Click Next 

![v5](C:\Users\Dulmi\Downloads\v5.png)

fill the required credentials and click Next

![v6](C:\Users\Dulmi\Downloads\v6.png)

Now make sure the location is correct where the ubuntu iso file is located and click Next

![v7](C:\Users\Dulmi\Downloads\v7.png)

The disk capacity should be 20 GB for 64 bit OS, if you choose 32 bit you may decrease it, Click Next

![v8](C:\Users\Dulmi\Downloads\v8.png)

Click on Customize Hardware to make sure our OS configuration is correct, choose CD/DVD 

![v9](C:\Users\Dulmi\Downloads\v9.png)

Make sure the ISO image file path is same (where you ubuntu iso file is located), Click Close and Finish

![image-20240128175756171](C:\Users\Dulmi\AppData\Roaming\Typora\typora-user-images\image-20240128175756171.png)

Now the Ubuntu will install different libraries 

![image-20240128180232517](C:\Users\Dulmi\AppData\Roaming\Typora\typora-user-images\image-20240128180232517.png)

Select the English US or any other official language and Click Continue

![image-20240128180418512](C:\Users\Dulmi\AppData\Roaming\Typora\typora-user-images\image-20240128180418512.png)

Choose the following selected options and Click Continue

![image-20240128180534551](C:\Users\Dulmi\AppData\Roaming\Typora\typora-user-images\image-20240128180534551.png)

Choose Erase disk and Install Now

![image-20240128180652315](C:\Users\Dulmi\AppData\Roaming\Typora\typora-user-images\image-20240128180652315.png)

Click Continue

![image-20240128180742458](C:\Users\Dulmi\AppData\Roaming\Typora\typora-user-images\image-20240128180742458.png)

Fill this credentials to login the ubuntu for later use

After this the installation of different packages required 10 to 15 minutes, after that

![image-20240128181013729](C:\Users\Dulmi\AppData\Roaming\Typora\typora-user-images\image-20240128181013729.png)

Choose Restart Now and login again using your credentials that you enter before.